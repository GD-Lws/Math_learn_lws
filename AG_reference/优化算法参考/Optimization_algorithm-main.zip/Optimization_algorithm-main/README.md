# Optimization_algorithm
群体智能优化算法
这是一个智能算法库，其中包括：
人工蜂群算法ABC
蚁群算法ACO
人工鱼群算法AFO
细菌觅食优化算法BFOA
萤火虫算法FA
遗传算法GA
免疫优化算法IA
粒子群优化算法PSO
模拟退火算法SA
禁忌搜索算法TS
布谷鸟搜索算法CS
